@echo off
title Rex WiFi Guard - Professional WiFi Analyzer
color 0B
echo ==========================================================
echo            REX WIFI GUARD v1.0 - LAUNCHING...
echo ==========================================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    py main.py
    exit /b 0
)

where python >nul 2>nul
if %errorlevel%==0 (
    python main.py
    exit /b 0
)

where python3 >nul 2>nul
if %errorlevel%==0 (
    python3 main.py
    exit /b 0
)

color 0C
echo [!] Python was not found on this computer.
echo.
echo     FIX (2 minutes):
echo     1. Open https://www.python.org/downloads/
echo     2. Download and run the installer.
echo     3. IMPORTANT: on the FIRST installer screen, tick
echo        the checkbox "Add python.exe to PATH" at the bottom.
echo     4. Install, then double-click run.bat again.
echo.
pause
